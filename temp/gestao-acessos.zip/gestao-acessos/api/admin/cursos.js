import { getPool } from '../lib/db.js';
import { setCors } from '../lib/helpers.js';
import { produtorDeQuemCadastra } from '../lib/produtor.js';

/**
 * Gestão de acessos a cursos.
 *
 *   GET    ?idAdmin=...                       lista usuários e cursos do produtor
 *   POST   {idAdmin, idUsuario, idCurso}      libera para uma pessoa
 *   POST   {idAdmin, idLider, idCurso,        libera para toda a rede de um líder
 *           modoRede: true}
 *   DELETE ?idAdmin=...&idCursoAluno=...      revoga (mantém o progresso)
 *
 * Revogar NÃO apaga a matrícula: muda o status para 3 (Bloqueado). Assim o
 * progresso do aluno sobrevive a uma revogação seguida de nova liberação.
 */

const STATUS_LIBERADO = 2;
const STATUS_BLOQUEADO = 3;

/** Quem chama pode gerir este produtor? Devolve o id do produtor ou null. */
async function autorizar(pool, idAdmin) {
  if (!idAdmin) return null;

  const { rows } = await pool.query(
    `SELECT id_nivel_de_acesso, bloqueado FROM usuario WHERE id = $1`,
    [idAdmin]
  );
  if (rows.length === 0 || rows[0].bloqueado) return null;
  if (rows[0].id_nivel_de_acesso < 6) return null;

  return await produtorDeQuemCadastra(pool, idAdmin);
}

export default async function handler(req, res) {
  setCors(res);
  if (req.method === 'OPTIONS') return res.status(200).end();

  // DELETE com corpo é instável neste runtime: lê da query, com o corpo como reserva
  const idAdmin = String(
    req.query.idAdmin ?? req.body?.idAdmin ?? ''
  ).trim();

  const pool = getPool();
  const idProdutor = await autorizar(pool, idAdmin);

  if (!idProdutor) {
    return res.status(200).json({ result: { error: true, errorCodes: ['SEM_PERMISSAO'] } });
  }

  try {
    if (req.method === 'GET')    return await listar(pool, idProdutor, res);
    if (req.method === 'POST')   return await liberar(pool, idProdutor, idAdmin, req, res);
    if (req.method === 'DELETE') return await revogar(pool, idProdutor, req, res);

    return res.status(405).json({ result: { error: true, errorCodes: ['METHOD_NOT_ALLOWED'] } });
  } catch (err) {
    console.error('[admin/cursos] erro:', err.message);
    return res.status(500).json({ result: { error: true, errorCodes: ['ERRO_INTERNO'] } });
  }
}

// ── GET ────────────────────────────────────────────────────────────────
async function listar(pool, idProdutor, res) {
  const usuarios = await pool.query(
    `SELECT u.id                                        AS "idUsuario",
            pf.nome, pf.sobrenome, e.email,
            u.is_lider                                  AS "isLider",
            u.bloqueado,
            COALESCE(
              json_agg(
                json_build_object(
                  'idCursoAluno', ca.id,
                  'idCurso',      ca.id_curso,
                  'nomeCurso',    c.nome
                ) ORDER BY c.nome
              ) FILTER (WHERE ca.id IS NOT NULL AND ca.id_status_meu_curso = $2),
              '[]'
            )                                           AS cursos
       FROM usuario u
       JOIN pessoa_fisica     pf ON pf.id = u.id_pessoa
       JOIN endereco_de_email e  ON e.id_pessoa = u.id_pessoa
       LEFT JOIN curso_aluno  ca ON ca.id_usuario = u.id AND ca.id_produtor = $1
       LEFT JOIN curso         c ON c.id = ca.id_curso
      WHERE EXISTS (
              SELECT 1 FROM curso_aluno x
               WHERE x.id_usuario = u.id AND x.id_produtor = $1
            )
         OR EXISTS (
              SELECT 1 FROM empreendedor_patrocinador ep
               WHERE ep.id_usuario = u.id AND ep.id_produtor = $1 AND ep.ativo
            )
      GROUP BY u.id, pf.nome, pf.sobrenome, e.email, u.is_lider, u.bloqueado
      ORDER BY pf.nome, pf.sobrenome`,
    [idProdutor, STATUS_LIBERADO]
  );

  const cursos = await pool.query(
    `SELECT c.id, c.nome
       FROM curso_produtor cp
       JOIN curso c ON c.id = cp.id_curso
      WHERE cp.id_produtor = $1
        AND COALESCE(c.status, 'ativo') <> 'inativo'
      ORDER BY cp.ordem NULLS LAST, c.nome`,
    [idProdutor]
  );

  return res.status(200).json({
    result: {
      error: false,
      usuarios: usuarios.rows,
      cursosDisponiveis: cursos.rows,
    },
  });
}

// ── POST ───────────────────────────────────────────────────────────────
async function liberar(pool, idProdutor, idAdmin, req, res) {
  const { idUsuario, idLider, idCurso, modoRede } = req.body || {};

  if (!idCurso) {
    return res.status(200).json({ result: { error: true, errorCodes: ['CAMPOS_OBRIGATORIOS'] } });
  }

  // o curso tem que pertencer a este produtor
  const doProdutor = await pool.query(
    `SELECT 1 FROM curso_produtor WHERE id_produtor = $1 AND id_curso = $2`,
    [idProdutor, idCurso]
  );
  if (doProdutor.rows.length === 0) {
    return res.status(200).json({ result: { error: true, errorCodes: ['CURSO_DE_OUTRO_PRODUTOR'] } });
  }

  // quem vai receber
  let alvos = [];
  if (modoRede) {
    if (!idLider) {
      return res.status(200).json({ result: { error: true, errorCodes: ['CAMPOS_OBRIGATORIOS'] } });
    }
    const rede = await pool.query(
      `SELECT ep.id_usuario
         FROM empreendedor_patrocinador ep
         JOIN usuario u ON u.id = ep.id_usuario
        WHERE ep.id_patrocinador = $1
          AND ep.id_produtor = $2
          AND ep.ativo = true
          AND u.bloqueado = false`,
      [idLider, idProdutor]
    );
    alvos = rede.rows.map((r) => r.id_usuario);
    alvos.push(idLider); // o próprio líder também recebe
  } else {
    if (!idUsuario) {
      return res.status(200).json({ result: { error: true, errorCodes: ['CAMPOS_OBRIGATORIOS'] } });
    }
    alvos = [idUsuario];
  }

  if (alvos.length === 0) {
    return res.status(200).json({ result: { error: true, errorCodes: ['NENHUM_DESTINATARIO'] } });
  }

  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    // uma consulta só para todos os alvos.
    // ON CONFLICT reativa quem estava bloqueado sem tocar no progresso.
    const inseridos = await client.query(
      `INSERT INTO curso_aluno
         (id_usuario, id_curso, id_produtor, id_status_meu_curso,
          origem_liberacao, liberado_por, dh_liberacao)
       SELECT unnest($1::varchar[]), $2, $3, $4, $5, $6, NOW()
       ON CONFLICT (id_usuario, id_curso) DO UPDATE
         SET id_status_meu_curso = EXCLUDED.id_status_meu_curso,
             id_produtor         = EXCLUDED.id_produtor,
             liberado_por        = EXCLUDED.liberado_por,
             dh_liberacao        = NOW()
       RETURNING id`,
      [
        alvos,
        idCurso,
        idProdutor,
        STATUS_LIBERADO,
        modoRede ? 'admin_rede' : 'admin_manual',
        idAdmin,
      ]
    );

    await client.query('COMMIT');
    console.info(`[admin/cursos] ${inseridos.rowCount} acesso(s) liberado(s) no produtor ${idProdutor}`);

    return res.status(200).json({
      result: { error: false, liberados: inseridos.rowCount },
    });
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
}

// ── DELETE ─────────────────────────────────────────────────────────────
async function revogar(pool, idProdutor, req, res) {
  const idCursoAluno = req.query.idCursoAluno ?? req.body?.idCursoAluno;

  if (!idCursoAluno) {
    return res.status(200).json({ result: { error: true, errorCodes: ['CAMPOS_OBRIGATORIOS'] } });
  }

  // bloqueia em vez de apagar: o progresso do aluno é preservado
  const { rowCount } = await pool.query(
    `UPDATE curso_aluno
        SET id_status_meu_curso = $3
      WHERE id = $1 AND id_produtor = $2`,
    [idCursoAluno, idProdutor, STATUS_BLOQUEADO]
  );

  if (rowCount === 0) {
    return res.status(200).json({ result: { error: true, errorCodes: ['MATRICULA_NAO_ENCONTRADA'] } });
  }

  console.info(`[admin/cursos] matrícula ${idCursoAluno} revogada no produtor ${idProdutor}`);
  return res.status(200).json({ result: { error: false } });
}
