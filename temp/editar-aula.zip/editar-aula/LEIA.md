# Página de edição de aula

## Atenção: a rota mudou de lugar

O arquivo `src/pages/cursos/[idCurso].js` virou
`src/pages/cursos/[idCurso]/index.js`.

Isso é obrigatório: o Next não aceita ter `[idCurso].js` e a pasta
`[idCurso]/` ao mesmo tempo. **Apague o arquivo antigo** depois de
descompactar, senão o build acusa conflito de rota.

```bash
rm "src/pages/cursos/[idCurso].js"
```

A URL para o usuário continua a mesma: `/cursos/<id>`.

## Estrutura final

```
src/pages/cursos/
├── index.js                      lista de cursos
└── [idCurso]/
    ├── index.js                  estrutura do curso
    └── aula/
        └── [idAula].js           edição da aula
```

## O que a tela de edição faz

- Editar o título, com salvamento explícito
- Trocar o vídeo, com barra de progresso
- Ver o vídeo atual no player, para conferir se subiu o arquivo certo
- Acompanhar o processamento, que se atualiza sozinho
- Excluir a aula

## Troca de vídeo, passo a passo

O vídeo novo é criado na Bunny e a aula passa a apontar para ele **antes**
de o antigo ser apagado. Se o envio falhar no meio, a aula fica com o
vídeo novo vazio, mas nunca em estado inconsistente — e o botão continua
lá para tentar de novo.
