import { getPool } from '../lib/db.js';
import { setCors } from '../lib/helpers.js';
import { autorizarGestao, podeEditarConteudo, moduloEhDoProdutor } from '../lib/autorizacao.js';

/**
 * Prova do módulo — uma por módulo, com questões e alternativas.
 *
 *   GET    ?idGestor=&idModulo=            carrega a prova inteira
 *   POST   {idGestor, idModulo, titulo}    cria a prova do módulo
 *   POST   {idGestor, idProva, enunciado}  adiciona questão
 *   POST   {idGestor, idQuestao, texto}    adiciona alternativa
 *   PUT    {idGestor, idProva, ...}        edita título, nota mínima, ativo
 *   PUT    {idGestor, idQuestao, ...}      edita enunciado e explicação
 *   PUT    {idGestor, idAlternativa, ...}  edita texto e marca a correta
 *   PUT    {idGestor, idProva, ordem:[]}   reordena questões
 *   DELETE ?idGestor=&idQuestao=           remove questão
 *   DELETE ?idGestor=&idAlternativa=       remove alternativa
 *
 * Marcar uma alternativa como correta desmarca as demais da questão: o app
 * do aluno assume resposta única e conta quantas corretas existem.
 */

async function provaEhDoProdutor(pool, idProva, idProdutor) {
  const { rows } = await pool.query(
    `SELECT 1 FROM prova p
       JOIN modulo m          ON m.id = p.id_modulo
       JOIN curso_produtor cp ON cp.id_curso = m.id_curso
      WHERE p.id = $1 AND cp.id_produtor = $2`,
    [idProva, idProdutor]
  );

  return rows.length > 0;
}

async function questaoEhDoProdutor(pool, idQuestao, idProdutor) {
  const { rows } = await pool.query(
    `SELECT q.id_prova FROM questao q
       JOIN prova p           ON p.id = q.id_prova
       JOIN modulo m          ON m.id = p.id_modulo
       JOIN curso_produtor cp ON cp.id_curso = m.id_curso
      WHERE q.id = $1 AND cp.id_produtor = $2`,
    [idQuestao, idProdutor]
  );

  return rows[0]?.id_prova ?? null;
}

async function alternativaEhDoProdutor(pool, idAlternativa, idProdutor) {
  const { rows } = await pool.query(
    `SELECT a.id_questao FROM alternativa a
       JOIN questao q         ON q.id = a.id_questao
       JOIN prova p           ON p.id = q.id_prova
       JOIN modulo m          ON m.id = p.id_modulo
       JOIN curso_produtor cp ON cp.id_curso = m.id_curso
      WHERE a.id = $1 AND cp.id_produtor = $2`,
    [idAlternativa, idProdutor]
  );

  return rows[0]?.id_questao ?? null;
}

export default async function handler(req, res) {
  setCors(res);
  if (req.method === 'OPTIONS') return res.status(200).end();

  const idGestor = String(req.query.idGestor ?? req.body?.idGestor ?? '').trim();

  const pool = getPool();
  const auth = await autorizarGestao(pool, idGestor);
  if (!auth.ok) return res.status(200).json({ result: { error: true, errorCodes: [auth.erro] } });

  try {
    if (req.method === 'GET') return await carregar(pool, auth, req, res);

    if (!podeEditarConteudo(auth)) {
      return res.status(200).json({ result: { error: true, errorCodes: ['SEM_PERMISSAO'] } });
    }

    if (req.method === 'POST')   return await inserir(pool, auth, req, res);
    if (req.method === 'PUT')    return await atualizar(pool, auth, req, res);
    if (req.method === 'DELETE') return await remover(pool, auth, req, res);

    return res.status(405).json({ result: { error: true, errorCodes: ['METHOD_NOT_ALLOWED'] } });
  } catch (err) {
    console.error('[gestao/prova] erro:', err.message);
    return res.status(500).json({ result: { error: true, errorCodes: ['ERRO_INTERNO'] } });
  }
}

// ── GET ────────────────────────────────────────────────────────────────
async function carregar(pool, auth, req, res) {
  const { idModulo } = req.query;
  if (!idModulo) {
    return res.status(200).json({ result: { error: true, errorCodes: ['CAMPOS_OBRIGATORIOS'] } });
  }
  if (!(await moduloEhDoProdutor(pool, idModulo, auth.idProdutor))) {
    return res.status(200).json({ result: { error: true, errorCodes: ['MODULO_NAO_ENCONTRADO'] } });
  }

  const { rows } = await pool.query(
    `SELECT id, titulo, nota_minima AS "notaMinima", ativo
       FROM prova WHERE id_modulo = $1 ORDER BY id DESC LIMIT 1`,
    [idModulo]
  );
  const prova = rows[0];
  if (!prova) {
    return res.status(200).json({ result: { error: false, prova: null, questoes: [] } });
  }

  const questoes = await pool.query(
    `SELECT q.id, q.enunciado, q.ordem, q.explicacao,
            COALESCE(
              json_agg(
                json_build_object(
                  'id',         a.id,
                  'texto',      a.texto,
                  'correta',    a.correta,
                  'ordem',      a.ordem,
                  'explicacao', a.explicacao
                ) ORDER BY a.ordem
              ) FILTER (WHERE a.id IS NOT NULL),
              '[]'
            ) AS alternativas
       FROM questao q
       LEFT JOIN alternativa a ON a.id_questao = q.id
      WHERE q.id_prova = $1
      GROUP BY q.id
      ORDER BY q.ordem`,
    [prova.id]
  );

  // alunos que já fizeram: editar depois disso afeta o histórico
  const { rows: uso } = await pool.query(
    `SELECT count(*) AS tentativas FROM tentativa_prova WHERE id_prova = $1`,
    [prova.id]
  );

  return res.status(200).json({
    result: {
      error: false,
      prova: { ...prova, tentativas: Number(uso[0].tentativas) },
      questoes: questoes.rows,
    },
  });
}

// ── POST ───────────────────────────────────────────────────────────────
async function inserir(pool, auth, req, res) {
  const { idModulo, titulo, idProva, enunciado, idQuestao, texto } = req.body || {};

  // nova alternativa
  if (idQuestao) {
    if (!(await questaoEhDoProdutor(pool, idQuestao, auth.idProdutor))) {
      return res.status(200).json({ result: { error: true, errorCodes: ['QUESTAO_NAO_ENCONTRADA'] } });
    }
    const { rows } = await pool.query(
      `INSERT INTO alternativa (id_questao, texto, correta, ordem)
       VALUES ($1, $2, false,
               (SELECT COALESCE(max(ordem), 0) + 1 FROM alternativa WHERE id_questao = $1))
       RETURNING id, ordem`,
      [idQuestao, (texto || 'Nova alternativa').trim()]
    );

    return res.status(200).json({ result: { error: false, idAlternativa: rows[0].id, ordem: rows[0].ordem } });
  }

  // nova questão, já com duas alternativas para não nascer vazia
  if (idProva) {
    if (!(await provaEhDoProdutor(pool, idProva, auth.idProdutor))) {
      return res.status(200).json({ result: { error: true, errorCodes: ['PROVA_NAO_ENCONTRADA'] } });
    }
    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      const { rows } = await client.query(
        `INSERT INTO questao (id_prova, enunciado, ordem)
         VALUES ($1, $2,
                 (SELECT COALESCE(max(ordem), 0) + 1 FROM questao WHERE id_prova = $1))
         RETURNING id, ordem`,
        [idProva, (enunciado || 'Nova questão').trim()]
      );
      await client.query(
        `INSERT INTO alternativa (id_questao, texto, correta, ordem)
         VALUES ($1, 'Alternativa 1', true, 1), ($1, 'Alternativa 2', false, 2)`,
        [rows[0].id]
      );
      await client.query('COMMIT');

      return res.status(200).json({ result: { error: false, idQuestao: rows[0].id, ordem: rows[0].ordem } });
    } catch (err) {
      await client.query('ROLLBACK');
      throw err;
    } finally {
      client.release();
    }
  }

  // nova prova
  if (!idModulo) {
    return res.status(200).json({ result: { error: true, errorCodes: ['CAMPOS_OBRIGATORIOS'] } });
  }
  if (!(await moduloEhDoProdutor(pool, idModulo, auth.idProdutor))) {
    return res.status(200).json({ result: { error: true, errorCodes: ['MODULO_NAO_ENCONTRADO'] } });
  }

  const existente = await pool.query(
    `SELECT id FROM prova WHERE id_modulo = $1 AND ativo = true`,
    [idModulo]
  );
  if (existente.rows.length > 0) {
    return res.status(200).json({ result: { error: true, errorCodes: ['MODULO_JA_TEM_PROVA'] } });
  }

  const { rows } = await pool.query(
    `INSERT INTO prova (id_modulo, titulo, nota_minima, ativo, dh_cadastro)
     VALUES ($1, $2, 80, false, NOW())
     RETURNING id`,
    [idModulo, (titulo || 'Prova do módulo').trim()]
  );

  return res.status(200).json({ result: { error: false, idProva: rows[0].id } });
}

// ── PUT ────────────────────────────────────────────────────────────────
async function atualizar(pool, auth, req, res) {
  const {
    idProva, titulo, notaMinima, ativo, ordem,
    idQuestao, enunciado, explicacao,
    idAlternativa, texto, correta,
  } = req.body || {};

  // alternativa
  if (idAlternativa) {
    const daQuestao = await alternativaEhDoProdutor(pool, idAlternativa, auth.idProdutor);
    if (!daQuestao) {
      return res.status(200).json({ result: { error: true, errorCodes: ['ALTERNATIVA_NAO_ENCONTRADA'] } });
    }

    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      // resposta única: marcar uma correta desmarca as outras
      if (correta === true) {
        await client.query(
          `UPDATE alternativa SET correta = false WHERE id_questao = $1`,
          [daQuestao]
        );
      }
      await client.query(
        `UPDATE alternativa
            SET texto      = COALESCE($2, texto),
                correta    = COALESCE($3, correta),
                explicacao = COALESCE($4, explicacao)
          WHERE id = $1`,
        [idAlternativa, texto?.trim() ?? null, correta ?? null, explicacao?.trim() ?? null]
      );
      await client.query('COMMIT');

      return res.status(200).json({ result: { error: false } });
    } catch (err) {
      await client.query('ROLLBACK');
      throw err;
    } finally {
      client.release();
    }
  }

  // questão
  if (idQuestao) {
    if (!(await questaoEhDoProdutor(pool, idQuestao, auth.idProdutor))) {
      return res.status(200).json({ result: { error: true, errorCodes: ['QUESTAO_NAO_ENCONTRADA'] } });
    }
    await pool.query(
      `UPDATE questao
          SET enunciado  = COALESCE($2, enunciado),
              explicacao = COALESCE($3, explicacao)
        WHERE id = $1`,
      [idQuestao, enunciado?.trim() ?? null, explicacao?.trim() ?? null]
    );

    return res.status(200).json({ result: { error: false } });
  }

  if (!idProva) {
    return res.status(200).json({ result: { error: true, errorCodes: ['CAMPOS_OBRIGATORIOS'] } });
  }
  if (!(await provaEhDoProdutor(pool, idProva, auth.idProdutor))) {
    return res.status(200).json({ result: { error: true, errorCodes: ['PROVA_NAO_ENCONTRADA'] } });
  }

  // reordenar questões
  if (Array.isArray(ordem)) {
    await pool.query(
      `UPDATE questao q SET ordem = n.pos
         FROM unnest($2::bigint[]) WITH ORDINALITY AS n(id, pos)
        WHERE q.id = n.id AND q.id_prova = $1`,
      [idProva, ordem]
    );

    return res.status(200).json({ result: { error: false } });
  }

  // publicar exige questão com resposta certa marcada
  if (ativo === true) {
    const { rows } = await pool.query(
      `SELECT count(*) AS validas
         FROM questao q
        WHERE q.id_prova = $1
          AND EXISTS (SELECT 1 FROM alternativa a
                       WHERE a.id_questao = q.id AND a.correta = true)`,
      [idProva]
    );
    if (Number(rows[0].validas) === 0) {
      return res.status(200).json({ result: { error: true, errorCodes: ['PROVA_SEM_QUESTAO_VALIDA'] } });
    }
  }

  await pool.query(
    `UPDATE prova
        SET titulo      = COALESCE($2, titulo),
            nota_minima = COALESCE($3, nota_minima),
            ativo       = COALESCE($4, ativo)
      WHERE id = $1`,
    [idProva, titulo?.trim() ?? null, notaMinima ?? null, ativo ?? null]
  );

  return res.status(200).json({ result: { error: false } });
}

// ── DELETE ─────────────────────────────────────────────────────────────
async function remover(pool, auth, req, res) {
  const idQuestao = req.query.idQuestao ?? req.body?.idQuestao;
  const idAlternativa = req.query.idAlternativa ?? req.body?.idAlternativa;

  if (idAlternativa) {
    const daQuestao = await alternativaEhDoProdutor(pool, idAlternativa, auth.idProdutor);
    if (!daQuestao) {
      return res.status(200).json({ result: { error: true, errorCodes: ['ALTERNATIVA_NAO_ENCONTRADA'] } });
    }
    // uma questão precisa de pelo menos duas opções
    const { rows } = await pool.query(
      `SELECT count(*) AS qtd FROM alternativa WHERE id_questao = $1`,
      [daQuestao]
    );
    if (Number(rows[0].qtd) <= 2) {
      return res.status(200).json({ result: { error: true, errorCodes: ['MINIMO_DUAS_ALTERNATIVAS'] } });
    }

    await pool.query(`DELETE FROM resposta_tentativa WHERE id_alternativa_escolhida = $1`, [idAlternativa]);
    await pool.query(`DELETE FROM alternativa WHERE id = $1`, [idAlternativa]);

    return res.status(200).json({ result: { error: false } });
  }

  if (idQuestao) {
    if (!(await questaoEhDoProdutor(pool, idQuestao, auth.idProdutor))) {
      return res.status(200).json({ result: { error: true, errorCodes: ['QUESTAO_NAO_ENCONTRADA'] } });
    }
    await pool.query(`DELETE FROM resposta_tentativa WHERE id_questao = $1`, [idQuestao]);
    await pool.query(`DELETE FROM alternativa WHERE id_questao = $1`, [idQuestao]);
    await pool.query(`DELETE FROM questao WHERE id = $1`, [idQuestao]);

    return res.status(200).json({ result: { error: false } });
  }

  return res.status(200).json({ result: { error: true, errorCodes: ['CAMPOS_OBRIGATORIOS'] } });
}
